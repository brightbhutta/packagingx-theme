<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package packagingx
 */
get_header('single'); ?>
	<?php echo 'Cat Product'; ?>
<?php get_footer(); ?>
