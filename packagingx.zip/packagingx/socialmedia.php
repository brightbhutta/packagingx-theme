<ul>
    <li><a href="https://www.facebook.com/packagingx/" title="Facebook"><i class="fab fa-facebook-f"></i></a></li>
    <li><a href="https://twitter.com/packaging_x" title="Twitter"><i class="fab fa-twitter"></i></a></li>
    <li><a href="https://www.instagram.com/packagingx/" title="Instagram"><i class="fab fa-instagram"></i></a></li>
    <li><a href="https://www.pinterest.com/thepackagingx/" title="Pinterest"><i class="fab fa-pinterest-p"></i></a></li>
</ul>